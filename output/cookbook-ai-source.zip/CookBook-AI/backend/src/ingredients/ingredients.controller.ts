import { Body, ConflictException, Controller, Get, Post, UseGuards } from "@nestjs/common";
import { Transform } from "class-transformer";
import { IsIn, IsString, Length } from "class-validator";
import { JwtAuthGuard } from "../auth/jwt-auth.guard";
import { PrismaService } from "../prisma/prisma.service";

const categories = ["Овочі", "Фрукти", "Ягоди", "Бобові", "Спеції", "Зелень", "Гриби", "Крупи", "Макаронні вироби", "М'ясо", "Риба та морепродукти", "Яйця", "Молочні продукти", "Горіхи та насіння", "Олії", "Консерви", "Інше"];
class CreateIngredientDto {
  @Transform(({ value }) => typeof value === "string" ? value.normalize("NFKC").trim().replace(/\s+/g, " ") : value)
  @IsString()
  @Length(2, 100)
  name!: string;

  @IsIn(categories)
  category!: string;
}

@Controller("ingredients")
export class IngredientsController {
  constructor(private readonly prisma: PrismaService) {}
  @Get()
  list() {
    return this.prisma.ingredient.findMany({ orderBy: { name: "asc" } });
  }

  @Get("categories")
  categories() { return categories; }

  @Post()
  @UseGuards(JwtAuthGuard)
  async create(@Body() dto: CreateIngredientDto) {
    const existing = await this.prisma.ingredient.findMany({ select: { name: true } });
    if (existing.some(item => item.name.normalize("NFKC").trim().replace(/\s+/g, " ").toLocaleLowerCase("uk") === dto.name.toLocaleLowerCase("uk"))) {
      throw new ConflictException("Такий інгредієнт уже є в каталозі. Оберіть його зі списку.");
    }
    try { return await this.prisma.ingredient.create({ data: dto }); }
    catch (error) {
      if ((error as { code?: string }).code === "P2002") throw new ConflictException("Такий інгредієнт уже є в каталозі.");
      throw error;
    }
  }
}
