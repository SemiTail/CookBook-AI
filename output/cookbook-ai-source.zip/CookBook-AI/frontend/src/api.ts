import type { Session } from "./types";

const BASE = (import.meta.env.VITE_API_URL || "/api/v1").replace(/\/$/, "");
const STORAGE_KEY = "cookbook-demo-session";

export class ApiError extends Error {
  constructor(message: string, public readonly status: number) { super(message); }
}

export function getSession(): Session | null {
  try {
    const raw = sessionStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) as Session : null;
  } catch { return null; }
}
export function saveSession(session: Session | null) {
  if (session) sessionStorage.setItem(STORAGE_KEY, JSON.stringify(session));
  else sessionStorage.removeItem(STORAGE_KEY);
}
export async function api<T>(path: string, init: RequestInit = {}): Promise<T> {
  const token = getSession()?.accessToken;
  let response: Response;
  try {
    response = await fetch(`${BASE}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...init.headers,
    },
    });
  } catch {
    throw new ApiError("Не вдалося з’єднатися із сервером. Перевірте підключення та спробуйте ще раз.", 0);
  }
  const data: unknown = await response.json().catch(() => ({}));
  if (!response.ok) {
    const err = data as { message?: string | string[] };
    throw new ApiError(Array.isArray(err.message) ? err.message.join("; ") : err.message ?? (response.status >= 500 ? "Сервер тимчасово недоступний. Спробуйте пізніше." : `HTTP ${response.status}`), response.status);
  }
  return data as T;
}
