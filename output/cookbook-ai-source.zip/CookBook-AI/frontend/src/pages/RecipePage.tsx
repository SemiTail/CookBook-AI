import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { api, getSession } from "../api";
import type { Recipe } from "../types";

export function RecipePage() {
  const { id } = useParams();
  const [recipe, setRecipe] = useState<Recipe | null>(null);
  const [error, setError] = useState("");
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const navigate = useNavigate();
  const owned = recipe?.authorId === getSession()?.user.id;

  async function remove() {
    if (!recipe || deleting) return;
    setDeleting(true); setError("");
    try { await api(`/recipes/${encodeURIComponent(recipe.id)}`, { method: "DELETE" }); navigate("/dashboard"); }
    catch (e) { setError(e instanceof Error ? e.message : "Не вдалося видалити рецепт"); }
    finally { setDeleting(false); }
  }

  useEffect(() => {
    let active = true;
    setRecipe(null);
    setError("");
    setConfirmDelete(false);

    if (id) {
      api<Recipe>(`/recipes/${encodeURIComponent(id)}`)
        .then((result) => {
          if (active) setRecipe(result);
        })
        .catch((e: unknown) => {
          if (active) {
            setError(
              e instanceof Error ? e.message : "Не вдалося відкрити рецепт",
            );
          }
        });
    } else {
      setError("Не вказано ідентифікатор рецепта");
    }

    return () => {
      active = false;
    };
  }, [id]);

  return (
    <div className="recipe-detail">
      <Link to="/dashboard" className="back">
        ← Повернутися до каталогу
      </Link>

      {error && <div className="error" role="alert">{error}</div>}
      {!recipe && !error && <p>Завантаження рецепта…</p>}

      {recipe && (
        <>
          <div className="detail-hero">
            <div className="emoji detail-emoji" aria-hidden="true">{recipe.emoji}</div>
            <span className="eyebrow">Кулінарний рецепт</span>
            <h1>{recipe.title}</h1>
            <p>{recipe.description}</p>
            <div className="recipe-meta">
              <span>⏱️ {recipe.preparationMinutes} хв</span>
              <span>🍴 {recipe.servings} порцій</span>
              <span>🔥 {recipe.calories ?? "—"} ккал/порція</span>
            </div>
          </div>

          {owned && <div className="recipe-actions owner-actions"><Link className="button" to={`/recipes/${encodeURIComponent(recipe.id)}/edit`}>Редагувати рецепт</Link><button className="button button-danger" onClick={() => setConfirmDelete(true)}>Видалити рецепт</button><span className="muted">{recipe.isPublished ? "Опублікований рецепт" : "Особистий рецепт · доступний лише вам"}</span></div>}
          {owned && confirmDelete && <section className="delete-confirm panel" role="alertdialog" aria-labelledby="delete-title"><h2 id="delete-title">Видалити «{recipe.title}»?</h2><p>Рецепт та його інгредієнти буде видалено з вашої книги. Цю дію не можна скасувати.</p><div className="recipe-actions"><button className="button button-danger" disabled={deleting} onClick={remove}>{deleting ? "Видаляємо…" : "Так, видалити"}</button><button className="button button-outline" disabled={deleting} onClick={() => setConfirmDelete(false)}>Залишити рецепт</button></div></section>}

          <div className="detail-grid">
            <section className="panel">
              <h2>Інгредієнти</h2>
              <ul className="ingredients-list">
                {recipe.ingredients.map((item) => (
                  <li key={item.ingredientId}>
                    <span>
                      {item.ingredient.name}
                      {item.optional ? " (необов’язково)" : ""}
                    </span>
                    <strong>
                      {item.quantity ?? "—"} {item.unit ?? ""}
                    </strong>
                  </li>
                ))}
              </ul>
              <p className="muted">
                КБЖУ на порцію: Б {recipe.protein ?? "—"} г · Ж{" "}
                {recipe.fat ?? "—"} г · В {recipe.carbs ?? "—"} г
              </p>
            </section>

            <section className="panel">
              <h2>Спосіб приготування</h2>
              <div className="steps">
                {recipe.instructions
                  .split(/\r?\n/)
                  .filter(Boolean)
                  .map((line, i) => (
                    <p key={i}>{line}</p>
                  ))}
              </div>
            </section>
          </div>
        </>
      )}
    </div>
  );
}
