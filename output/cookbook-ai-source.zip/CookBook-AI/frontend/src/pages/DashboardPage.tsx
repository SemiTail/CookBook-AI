import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api, ApiError } from "../api";
import type { FridgeItem, Ingredient, Recipe, User } from "../types";
import { AssistantChat, type ChatMode } from "../AssistantChat";
import { FridgePanel } from "../FridgePanel";

export function DashboardPage({ onUnauthorized }: { onUnauthorized: () => void }) {
  const [user, setUser] = useState<User | null>(null);
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [myRecipes, setMyRecipes] = useState<Recipe[]>([]);
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [fridge, setFridge] = useState<FridgeItem[]>([]);
  const [suggestions, setSuggestions] = useState<Recipe[]>([]);
  const [chatMode, setChatMode] = useState<ChatMode>("closed");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  const handleError = useCallback((e: unknown) => {
    if (e instanceof ApiError && e.status === 401) onUnauthorized();
    else setError(e instanceof Error ? e.message : "Помилка завантаження");
  }, [onUnauthorized]);

  const refresh = useCallback(async () => {
    try {
      const [items, matches, catalog] = await Promise.all([api<FridgeItem[]>("/fridge"), api<Recipe[]>("/recommendations"), api<Ingredient[]>("/ingredients")]);
      setFridge(items); setSuggestions(matches); setIngredients(catalog); setError("");
    } catch (e) { handleError(e); }
  }, [handleError]);

  useEffect(() => {
    let active = true;
    Promise.all([api<User>("/users/me"), api<Recipe[]>("/recipes"), api<Ingredient[]>("/ingredients"), api<FridgeItem[]>("/fridge"), api<Recipe[]>("/recommendations"), api<Recipe[]>("/recipes/mine")])
      .then(([me, r, i, items, matches, mine]) => { if (active) { setUser(me); setRecipes(r); setIngredients(i); setFridge(items); setSuggestions(matches); setMyRecipes(mine); } })
      .catch((e: unknown) => { if (active) handleError(e); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [handleError]);

  return <>
    <div className="dashboard-heading"><section className="welcome"><span className="eyebrow">Твоя кулінарна книга</span><h1>Вітаємо{user ? `, ${user.name}` : ""} 👋</h1><p>Обери продукти, які маєш, і знайди страву на сьогодні.</p></section><button className="button assistant-toggle" aria-expanded={chatMode === "open"} onClick={() => setChatMode(mode => mode === "open" ? "closed" : "open")}>✦ ШІ-помічник</button></div>
    {user && <p className="muted">Ви увійшли як {user.email}</p>}
    {error && <div className="error" role="alert">{error} <button onClick={() => window.location.reload()}>Повторити</button></div>}
    {loading ? <p>Завантажуємо дані…</p> : <div className={`dashboard-layout ${chatMode === "open" ? "is-chat-open" : ""}`}><div className="dashboard-content">
      <FridgePanel fridge={fridge} ingredients={ingredients} onChanged={refresh} onError={handleError} />
      <section className="my-recipes"><div className="section-header"><div><span className="eyebrow">Особиста кулінарна книга</span><h2>Мої рецепти <span className="count">{myRecipes.length}</span></h2></div><Link className="button" to="/recipes/new">+ Створити рецепт</Link></div>
        {myRecipes.length ? <div className="cards">{myRecipes.map(recipe => <RecipeCard key={recipe.id} recipe={recipe} />)}</div> : <div className="empty">Тут з’являться ваші рецепти. Додайте улюблену страву з власним емодзі та інструкцією приготування.</div>}
      </section>
      <section className="recipes-section"><div className="section-header"><div><span className="eyebrow">Підбір від 70% відповідності</span><h2>Можна приготувати <span className="count">{suggestions.length}</span></h2></div></div>
        {suggestions.length ? <div className="cards">{suggestions.map(r => <RecipeCard key={r.id} recipe={r} />)}</div> : <div className="empty">Поки немає рецептів із відповідністю від 70%. Додай ще кілька інгредієнтів.</div>}
      </section>
      <section className="recipes-section"><div className="section-header"><div><span className="eyebrow">Повна колекція</span><h2>Усі рецепти <span className="count">{recipes.length}</span></h2></div></div><div className="cards">{recipes.map(r => <RecipeCard key={r.id} recipe={r} />)}</div></section>
    </div><AssistantChat mode={chatMode} onMode={setChatMode} fridgeCount={fridge.length} /></div>}
  </>;
}

function RecipeCard({ recipe }: { recipe: Recipe }) {
  const difficulty: Record<Recipe["difficulty"], string> = { EASY: "Просто", MEDIUM: "Середньо", HARD: "Складно" };
  return <Link className="recipe-card" to={`/recipes/${encodeURIComponent(recipe.id)}`}>
    <div className="recipe-art emoji" aria-hidden="true">{recipe.emoji}</div>
    <div className="recipe-content"><h3>{recipe.title}</h3><p>{recipe.description || "Домашній рецепт"}</p><div className="recipe-meta"><span>⏱ {recipe.preparationMinutes} хв</span><span>◈ {difficulty[recipe.difficulty]}</span>{typeof recipe.matchPercent === "number" && <strong>{recipe.matchPercent}% є</strong>}</div></div>
  </Link>;
}

