import { useState, type Dispatch, type SetStateAction } from "react";
import { api } from "./api";
import { IngredientCreator } from "./IngredientCreator";
import type { FridgeItem, Ingredient } from "./types";

export function FridgePanel({ fridge, ingredients, onChanged, onError }: { fridge: FridgeItem[]; ingredients: Ingredient[]; onChanged: () => Promise<void>; onError: (e: unknown) => void }) {
  const [selected, setSelected] = useState("");
  const [picker, setPicker] = useState(false);
  const [search, setSearch] = useState("");
  const [toAdd, setToAdd] = useState<string[]>([]);
  const [toRemove, setToRemove] = useState<string[]>([]);
  const [pending, setPending] = useState(false);
  const [confirm, setConfirm] = useState<"all" | "selected" | null>(null);
  const [category, setCategory] = useState("");
  const [sort, setSort] = useState("name");
  const categories = [...new Set(ingredients.map(item => item.category))].sort((a, b) => a.localeCompare(b, "uk"));
  const compare = (a: Ingredient, b: Ingredient) => (sort === "category" ? a.category.localeCompare(b.category, "uk") : 0) || a.name.localeCompare(b.name, "uk") * (sort === "reverse" ? -1 : 1);
  const visibleFridge = fridge.filter(item => !category || item.ingredient.category === category).sort((a, b) => compare(a.ingredient, b.ingredient));
  const owned = new Set(fridge.map(item => item.ingredientId));
  const available = ingredients.filter(item => !owned.has(item.id) && (!category || item.category === category)).sort(compare);
  const filtered = available.filter(item => `${item.name} ${item.category}`.toLocaleLowerCase("uk").includes(search.trim().toLocaleLowerCase("uk")));
  const marked = toRemove.filter(id => fridge.some(item => item.id === id));
  function toggle(setter: Dispatch<SetStateAction<string[]>>, id: string) { setter(items => items.includes(id) ? items.filter(value => value !== id) : [...items, id]); }
  async function mutate(action: () => Promise<unknown>, success: () => void = () => {}) {
    if (pending) return;
    setPending(true);
    try { await action(); success(); await onChanged(); }
    catch (error) { onError(error); }
    finally { setPending(false); }
  }
  function bulkAdd() {
    const ingredientIds = toAdd.filter(id => !owned.has(id));
    if (!ingredientIds.length) return;
    void mutate(() => api("/fridge/bulk", { method: "POST", body: JSON.stringify({ ingredientIds }) }), () => { setToAdd([]); setPicker(false); setSearch(""); });
  }
  function removeConfirmed() {
    void mutate(() => api(confirm === "all" ? "/fridge" : "/fridge/selected", { method: "DELETE", ...(confirm === "selected" ? { body: JSON.stringify({ ids: marked }) } : {}) }), () => { setToRemove([]); setConfirm(null); });
  }
  return <section className="panel fridge-panel">
    <div className="section-header"><div><span className="eyebrow">Твій запас продуктів</span><h2>Мій холодильник <span className="count">{fridge.length}</span></h2></div><button className="text-button danger-text" disabled={!fridge.length || pending} onClick={() => setConfirm("all")}>Очистити холодильник</button></div>
    <div className="ingredient-controls"><label>Тип продуктів<select aria-label="Тип продуктів" value={category} onChange={e => { setCategory(e.target.value); setSelected(""); }}><option value="">Усі типи</option>{categories.map(value => <option key={value}>{value}</option>)}</select></label><label>Сортування продуктів<select aria-label="Сортування продуктів" value={sort} onChange={e => setSort(e.target.value)}><option value="name">Назва: А–Я</option><option value="reverse">Назва: Я–А</option><option value="category">За типом, потім за назвою</option></select></label></div>
    <IngredientCreator onCreated={async item => { setCategory(""); await onChanged(); setSelected(item.id); }} />
    <div className="ingredient-form"><select aria-label="Інгредієнт" value={selected} disabled={pending} onChange={e => setSelected(e.target.value)}><option value="">Оберіть інгредієнт…</option>{available.map(item => <option key={item.id} value={item.id}>{item.name} · {item.category}</option>)}</select><button className="button" disabled={!selected || pending} onClick={() => void mutate(() => api("/fridge", { method: "POST", body: JSON.stringify({ ingredientId: selected }) }), () => setSelected(""))}>+ Додати</button></div>
    <button className="button button-outline button-small multi-picker-toggle" disabled={pending} aria-expanded={picker} onClick={() => setPicker(value => !value)}>Обрати кілька продуктів</button>
    {picker && <div className="product-picker"><label className="search-label">Пошук продуктів<input value={search} onChange={e => setSearch(e.target.value)} placeholder="Назва або категорія" /></label><div className="picker-tools"><span className="muted">Обрано: {toAdd.filter(id => !owned.has(id)).length}</span><button className="text-button" disabled={pending || !filtered.length} onClick={() => setToAdd(previous => [...new Set([...previous, ...filtered.map(item => item.id)])].slice(0, 200))}>Обрати знайдені</button><button className="text-button" disabled={pending} onClick={() => setToAdd([])}>Скинути вибір</button></div><div className="product-options">{filtered.length ? filtered.map(item => <label key={item.id}><input type="checkbox" aria-label={`Додати ${item.name}`} checked={toAdd.includes(item.id)} disabled={pending || (!toAdd.includes(item.id) && toAdd.length >= 200)} onChange={() => toggle(setToAdd, item.id)} /><span>{item.name}<small>{item.category}</small></span></label>) : <p className="muted">Немає продуктів за цим пошуком.</p>}</div><button className="button button-small" disabled={pending || !toAdd.some(id => !owned.has(id))} onClick={bulkAdd}>Додати обрані</button></div>}
    {fridge.length > 0 && <div className="fridge-selection"><label><input type="checkbox" aria-label="Обрати всі продукти в холодильнику" checked={visibleFridge.length > 0 && visibleFridge.every(item => marked.includes(item.id))} disabled={pending || !visibleFridge.length} onChange={e => setToRemove(e.target.checked ? [...new Set([...marked, ...visibleFridge.map(item => item.id)])].slice(0, 200) : marked.filter(id => !visibleFridge.some(item => item.id === id)))} /> {category ? "Обрати всі видимі" : "Обрати всі"}</label><span className="muted">Обрано: {marked.length}</span><button className="text-button danger-text" disabled={!marked.length || pending} onClick={() => setConfirm("selected")}>Видалити обрані</button></div>}
    <div className="pills">{visibleFridge.length ? visibleFridge.map(item => <span className={`pill ${marked.includes(item.id) ? "pill-selected" : ""}`} key={item.id}><label><input type="checkbox" aria-label={`Обрати ${item.ingredient.name}`} checked={marked.includes(item.id)} disabled={pending || (!marked.includes(item.id) && marked.length >= 200)} onChange={() => toggle(setToRemove, item.id)} />{item.ingredient.name}<small className="category-tag">{item.ingredient.category}</small></label><button aria-label={`Видалити ${item.ingredient.name}`} title="Видалити" disabled={pending} onClick={() => void mutate(() => api(`/fridge/${item.id}`, { method: "DELETE" }), () => setToRemove(values => values.filter(id => id !== item.id)))}>×</button></span>) : <p className="muted">{fridge.length ? "У холодильнику немає продуктів цього типу." : "Холодильник порожній. Додайте перший інгредієнт."}</p>}</div>
    {confirm && <div className="fridge-confirm" role="alertdialog" aria-label="Підтвердження очищення холодильника"><p>{confirm === "all" ? "Видалити всі продукти з вашого холодильника?" : `Видалити обрані продукти (${marked.length})?`}</p><div className="recipe-actions"><button className="button button-danger button-small" disabled={pending} onClick={removeConfirmed}>Так, видалити продукти</button><button className="button button-outline button-small" disabled={pending} onClick={() => setConfirm(null)}>Скасувати</button></div></div>}
  </section>;
}
